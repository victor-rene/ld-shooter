from kivy.core.audio import SoundLoader


sfx_laser1 = SoundLoader.load('sfx/laser.wav')
sfx_laser2 = SoundLoader.load('sfx/laser.wav')