from kivy.uix.popup import Popup


class NewGame(Popup):
  
  def __init__(self, **kw):
    super(NewGame, self).__init__(**kw)