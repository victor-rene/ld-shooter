def check_classname(obj, cls_name):
  return obj.__class__.__name__ == cls_name